import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TrustHighlights } from './components/TrustHighlights';
import { ProductsSection } from './components/ProductsSection';
import { WholesaleSection } from './components/WholesaleSection';
import { PrivateLabelSection } from './components/PrivateLabelSection';
import { WhyPakistanSalt } from './components/WhyPakistanSalt';
import { ExportProcess } from './components/ExportProcess';
import { FeaturedGallery } from './components/FeaturedGallery';
import { EnquiryForm } from './components/EnquiryForm';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { QuoteModal } from './components/QuoteModal';

export default function App() {
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [selectedProductForQuote, setSelectedProductForQuote] = useState('Food-Grade Pink Salt');

  const handleOpenQuoteModal = (productName?: string) => {
    if (productName) {
      setSelectedProductForQuote(productName);
    }
    setIsQuoteModalOpen(true);
  };

  const handleCloseQuoteModal = () => {
    setIsQuoteModalOpen(false);
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.querySelector(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectProduct = (productName: string) => {
    setSelectedProductForQuote(productName);
    // Smoothly scroll to the form and pre-fill it
    const contactEl = document.querySelector('#contact');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth' });
    } else {
      setIsQuoteModalOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#090a0d] text-[#f7f3ed] selection:bg-[#d9b16f] selection:text-[#090a0d]">
      {/* Top Navigation */}
      <Navbar onRequestQuote={() => handleOpenQuoteModal()} />

      <main>
        {/* Cinematic Hero */}
        <Hero
          onExploreProducts={() => scrollToSection('#products')}
          onRequestWholesale={() => handleOpenQuoteModal('Bulk Supply')}
        />

        {/* Trust & Export Highlights */}
        <TrustHighlights />

        {/* Our Products Section */}
        <ProductsSection onSelectProductForQuote={handleSelectProduct} />

        {/* Wholesale & Bulk Export */}
        <WholesaleSection onRequestQuote={() => handleOpenQuoteModal('Bulk Supply')} />

        {/* Private Label & Custom Packaging */}
        <PrivateLabelSection onDiscussPackaging={() => handleOpenQuoteModal('Private Label Products')} />

        {/* Why Pakistani Himalayan Pink Salt? */}
        <WhyPakistanSalt />

        {/* How the Export Enquiry Process Works */}
        <ExportProcess />

        {/* Featured Photographic Gallery */}
        <FeaturedGallery onSelectProductForQuote={handleSelectProduct} />

        {/* International Buyer Enquiry Form */}
        <EnquiryForm initialProduct={selectedProductForQuote} />

        {/* Final Call to Action */}
        <FinalCTA
          onRequestQuote={() => handleOpenQuoteModal()}
          onExploreProducts={() => scrollToSection('#products')}
        />
      </main>

      {/* Footer */}
      <Footer
        onSelectProduct={handleSelectProduct}
        onRequestQuote={() => handleOpenQuoteModal()}
        onNavigate={scrollToSection}
      />

      {/* Floating WhatsApp Contact Button (Automatically hidden if no real number is configured) */}
      <WhatsAppButton />

      {/* Fast Quotation Modal */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={handleCloseQuoteModal}
        defaultProduct={selectedProductForQuote}
      />
    </div>
  );
}
