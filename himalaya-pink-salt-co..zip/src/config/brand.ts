/**
 * HIMALAYA PINK SALT CO. - Central Brand & Export Configuration
 *
 * All brand metadata, company details, contact endpoints, and product specifications
 * are configured here. Modifying this file updates the entire site without code changes.
 */

export interface ProductItem {
  id: string;
  name: string;
  category: string;
  tagline: string;
  description: string;
  detailedSpecs: {
    origin: string;
    grainSize?: string;
    colorProfile: string;
    packagingOptions: string[];
    typicalApplications: string[];
    exportPacking: string;
  };
  image: string;
  ctaText: string;
}

export interface BrandConfig {
  name: string;
  legalEntityName: string;
  tagline: string;
  headerSubtitle: string;
  originBadge: string;
  originRegion: string;
  saltMineOrigin: string;

  // Contact & Inquiries (Honest business defaults)
  contactEmail: string;
  // If whatsAppNumber is empty or not configured, the floating WhatsApp widget is hidden
  whatsAppNumber: string;
  whatsAppPrefillMessage: string;
  businessAddress: {
    city: string;
    region: string;
    country: string;
    fullLocation: string;
  };

  // Export terms & coordination
  acceptedIncoterms: string[];
  exportPackagingTypes: string[];
  orderQuantities: string[];

  // Products
  products: ProductItem[];
}

export const BRAND_CONFIG: BrandConfig = {
  name: 'HIMALAYA PINK SALT CO.',
  legalEntityName: 'Himalaya Pink Salt Co. (Pvt) Ltd.',
  tagline: "From Pakistan's Salt Mountains to the World.",
  headerSubtitle: 'PAKISTAN · GLOBAL EXPORTS',
  originBadge: 'Authentic Pakistan Origin',
  originRegion: 'Salt Range, Punjab, Pakistan',
  saltMineOrigin: 'Khewra & Kalabagh Salt Range Belt',

  // Real contact details for international trade communication
  contactEmail: 'exports@himalayapinksalt.pk',
  // Set real WhatsApp number in international format e.g. "923001234567". Empty string hides the widget.
  whatsAppNumber: '', // Default empty so floating widget stays hidden until business owner supplies number
  whatsAppPrefillMessage:
    'Hello, I am interested in your Pakistani Himalayan Pink Salt products. Please share product specifications, packaging options, wholesale pricing, and export details.',

  businessAddress: {
    city: 'Lahore / Jhelum',
    region: 'Punjab',
    country: 'Pakistan',
    fullLocation: 'Export Logistics Hub, Salt Range Corridor, Punjab, Pakistan',
  },

  acceptedIncoterms: ['FOB (Free on Board)', 'CIF (Cost, Insurance & Freight)', 'CFR (Cost & Freight)', 'EXW (Ex Works)'],

  exportPackagingTypes: [
    '25 kg Multi-Wall Woven PP / PE Bags',
    '50 kg Export Grade Sacks',
    '1 Ton / 1.2 Ton Bulk Jumbo Bags (FIBC)',
    'Retail Stand-up Pouches (250g - 1kg)',
    'Glass Grinder Jars (100g - 250g)',
    'Rigid Master Export Cartons',
    'Custom Palletized & Shrink-Wrapped Loads',
  ],

  orderQuantities: [
    'Trial Pallet / Sample Evaluation (1 - 5 Metric Tons)',
    'Half Container Load (10 - 12 Metric Tons)',
    '20ft FCL Container (Approx. 24 - 26 Metric Tons)',
    '40ft FCL Container (Approx. 27 - 28 Metric Tons)',
    'Multiple Container Contract (Monthly / Quarterly)',
    'Custom Bulk Quantity Inquiry',
  ],

  products: [
    {
      id: 'food-grade-pink-salt',
      name: 'Food-Grade Pink Salt',
      category: 'Culinary Grade',
      tagline: 'Pure, mineral-rich culinary grade salt crystals',
      description:
        'Himalayan pink salt products for food-related applications, subject to the required grade and quality specifications.',
      detailedSpecs: {
        origin: 'Salt Range, Punjab, Pakistan',
        grainSize: 'Extra Fine (0.1–0.3mm), Fine (0.3–0.8mm), Medium (1–2mm)',
        colorProfile: 'Natural Light Pink to Vibrant Rose Amber',
        packagingOptions: ['25kg Export Bags', '1 Ton Jumbo Bags', 'Retail Pouches (500g / 1kg)'],
        typicalApplications: ['Table Salt', 'Bakery & Food Processing', 'Pickling & Curing', 'Spice Blends'],
        exportPacking: 'Moisture-barrier food contact inner liner with heavy PP outer sack',
      },
      image: '/src/assets/images/food_grade_pink_salt_crystals_1792434902437.jpg',
      ctaText: 'Enquire About This Product',
    },
    {
      id: 'fine-coarse-grains',
      name: 'Pink Salt Fine & Coarse Grains',
      category: 'Grain Grading',
      tagline: 'Precision-sieved mesh classifications',
      description:
        'Different grain sizes for food manufacturers, distributors, retail packaging, and other suitable applications.',
      detailedSpecs: {
        origin: 'Salt Range, Punjab, Pakistan',
        grainSize: 'Fine (20-40 Mesh), Coarse (2-5mm), Coarse Grinder Cut (3-6mm)',
        colorProfile: 'Blush Rose, Peachy Amber, Translucent White crystals',
        packagingOptions: ['Bulk 25kg / 50kg Bags', 'Clear Window Standup Bags', 'PET Jars'],
        typicalApplications: ['Refillable Salt Grinders', 'Butcheries', 'Seasoning Mixes', 'Bath Soak Bases'],
        exportPacking: 'Standard palletized 20ft container loads with stretch-wrap moisture protection',
      },
      image: '/src/assets/images/fine_coarse_salt_grains_1792434903248.jpg',
      ctaText: 'Request Specifications',
    },
    {
      id: 'salt-chunks',
      name: 'Himalayan Pink Salt Chunks',
      category: 'Raw Minerals',
      tagline: 'Authentic natural geological crystal pieces',
      description:
        'Natural salt chunks available for enquiries concerning suitable commercial and decorative uses.',
      detailedSpecs: {
        origin: 'Salt Range, Punjab, Pakistan',
        grainSize: 'Rough irregular boulders 2cm–5cm, 5cm–10cm, and jumbo 15cm+',
        colorProfile: 'Deep Dark Pink, Ruby Salmon, White crystalline striations',
        packagingOptions: ['25kg Carton Boxes with separators', 'Bulk Sacks', 'Wooden Crates'],
        typicalApplications: ['Sole Water Preparation', 'Sauna & Salt Wall Construction', 'Spa Installations', 'Decorative Displays'],
        exportPacking: 'Cushioned corrugated cartons to prevent edge chipping in maritime transit',
      },
      image: '/src/assets/images/natural_salt_chunks_1792434904307.jpg',
      ctaText: 'Ask About Bulk Supply',
    },
    {
      id: 'salt-lamps',
      name: 'Pink Salt Lamps',
      category: 'Decorative & Wellness',
      tagline: 'Artisan carved natural crystal luminaires',
      description:
        'Decorative pink salt lamp products for home retailers, gift businesses, and wholesale buyers.',
      detailedSpecs: {
        origin: 'Handcrafted in Pakistan Salt Range craft centres',
        grainSize: 'Weight classes: 2-3kg, 3-5kg, 5-7kg, 7-10kg, and custom giants',
        colorProfile: 'Warm Amber, Peach Glow, Rose Sunset Translucence',
        packagingOptions: ['Individual Color Gift Boxes', 'Neutral White Inner Boxes', 'Export Master Cartons'],
        typicalApplications: ['Interior Lighting', 'Home Decor Retailers', 'Wellness & Yoga Centers', 'Gift Stores'],
        exportPacking: 'Drop-tested individual box packaging with certified electrical cords according to destination region (UL, CE, UKCA, SAA)',
      },
      image: '/src/assets/images/illuminated_salt_lamps_1792434905482.jpg',
      ctaText: 'Enquire About Salt Lamps',
    },
    {
      id: 'cooking-blocks',
      name: 'Pink Salt Cooking Blocks',
      category: 'Gourmet Slabs',
      tagline: 'Solid crystalline culinary cooking and serving platters',
      description:
        'Salt cooking slabs and related products for suitable culinary and hospitality applications.',
      detailedSpecs: {
        origin: 'Selected high-density crystal seams, Punjab, Pakistan',
        grainSize: 'Dimensions: 8"x8"x2", 8"x12"x1.5", 8"x16"x2", round platters',
        colorProfile: 'Layered pink marble striations, high structural crystal density',
        packagingOptions: ['Individual protective cartons', 'Retail shrink-wrapped boxes with metal serving trays'],
        typicalApplications: ['Searing Meats & Seafood', 'Cold Serving Trays (Sushi/Carpaccio)', 'Gourmet Retail'],
        exportPacking: 'Heavy-gauge individual buffer packaging inside reinforced master export cases',
      },
      image: '/src/assets/images/salt_cooking_blocks_1792434905448.jpg',
      ctaText: 'Request Product Details',
    },
    {
      id: 'custom-branded',
      name: 'Custom-Branded Pink Salt',
      category: 'Private Label',
      tagline: 'Turnkey private label branding and retail-ready packaging',
      description:
        'Explore packaging and private-label possibilities based on product specifications, order quantities, and available production arrangements.',
      detailedSpecs: {
        origin: 'Pakistan Salt Range with customer-specified export finishing',
        grainSize: 'Custom selected grain meshes per brand requirements',
        colorProfile: 'Standard Pink, Dark Rose, or White Crystal sorting',
        packagingOptions: ['Matte & Kraft Pouches with Zip', 'Custom Printed Tins & Jars', 'Custom Barcode & Retail Cartons'],
        typicalApplications: ['Private Supermarket Brands', 'Gourmet Food Labels', 'Amazon & E-commerce Sellers'],
        exportPacking: 'Retail shelf-ready packaging (SRP) and custom display shipper trays',
      },
      image: '/src/assets/images/private_label_salt_packaging_1792434907377.jpg',
      ctaText: 'Discuss Private Label',
    },
  ],
};
