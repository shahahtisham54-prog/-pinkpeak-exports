import React from 'react';
import { ArrowRight } from 'lucide-react';

interface FinalCTAProps {
  onRequestQuote: () => void;
  onExploreProducts: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onRequestQuote, onExploreProducts }) => {
  return (
    <section className="relative py-28 overflow-hidden bg-[#090a0d] border-t border-[#d9b16f]/20">
      {/* Background with Darkened Mineral Image Scrim */}
      <div className="absolute inset-0 z-0 opacity-25">
        <img
          src="/src/assets/images/hero_himalayan_salt_landscape_1792434901533.jpg"
          alt="Himalayan pink salt textures and mountains background"
          className="w-full h-full object-cover object-center filter saturate-150"
          referrerPolicy="no-referrer"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-[#090a0d]/85" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d] via-transparent to-[#090a0d]" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 mb-4 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
          <span className="w-6 h-[1.5px] bg-[#d9b16f]" />
          <span>DIRECT FROM THE SOURCE</span>
          <span className="w-6 h-[1.5px] bg-[#d9b16f]" />
        </div>

        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-serif-luxury text-[#f7f3ed] mb-6 tracking-tight leading-[1.12]">
          Take Pakistani Pink Salt <br />
          <span className="italic text-[#f3d59a]">to Your Market.</span>
        </h2>

        <p className="text-base sm:text-lg text-[#bdb7b0] max-w-2xl mx-auto font-light leading-relaxed mb-10">
          Whether you are a wholesaler, importer, distributor, retailer, or private-label brand, start a
          conversation about your requirements.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onRequestQuote}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-9 py-4 text-xs font-semibold uppercase tracking-[0.14em] text-[#090a0d] bg-gradient-to-r from-[#d9b16f] via-[#f3d59a] to-[#d9b16f] hover:brightness-105 transition-all duration-300 rounded-sm shadow-[0_4px_25px_rgba(217,177,111,0.35)] cursor-pointer"
          >
            <span>Request an Export Quote</span>
            <ArrowRight className="w-4 h-4 text-[#090a0d]" />
          </button>

          <button
            onClick={onExploreProducts}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 text-xs font-semibold uppercase tracking-[0.14em] text-[#f7f3ed] bg-[#1b1b20] hover:bg-[#25252c] border border-[#d9b16f]/30 hover:border-[#d9b16f] transition-all rounded-sm cursor-pointer"
          >
            <span>Explore Our Products</span>
          </button>
        </div>
      </div>
    </section>
  );
};
