import React from 'react';
import { BRAND_CONFIG } from '../config/brand';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
}) => {
  const iconSizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-13 h-13',
  };

  const titleSizes = {
    sm: 'text-sm tracking-wider',
    md: 'text-base lg:text-lg tracking-[0.14em]',
    lg: 'text-xl lg:text-2xl tracking-[0.16em]',
  };

  return (
    <div className={`flex items-center gap-3.5 select-none ${className}`}>
      {/* Original Geometric Mountain + Salt Crystal Vector Mark */}
      <div
        className={`relative ${iconSizes[size]} flex-shrink-0 rounded-lg p-1.5 bg-gradient-to-b from-[#1b1b22] to-[#0d0e12] border border-[#d9b16f]/30 shadow-md group transition-all duration-300 hover:border-[#d9b16f]/60`}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full drop-shadow-[0_2px_8px_rgba(216,154,157,0.25)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Distant mountain silhouette */}
          <path
            d="M8 82L38 32L62 65L74 46L92 82H8Z"
            fill="url(#mountainGrad)"
            opacity="0.5"
          />
          {/* Majestic Foreground Himalayan Peaks */}
          <path
            d="M16 82L50 22L72 58L84 82H16Z"
            fill="url(#goldRidgeGrad)"
            stroke="#d9b16f"
            strokeWidth="1.2"
          />
          {/* Faceted Pink Salt Mineral Crystal Geometry */}
          <path
            d="M50 22L65 42L50 78L35 42L50 22Z"
            fill="url(#crystalGrad)"
            opacity="0.9"
          />
          {/* Translucent crystal facets */}
          <path
            d="M50 22L50 78L65 42L50 22Z"
            fill="#d89a9d"
            opacity="0.45"
          />
          <path
            d="M50 22L35 42L50 56L50 22Z"
            fill="#f0d2d0"
            opacity="0.75"
          />
          {/* Subtle crystal crown highlight */}
          <circle cx="50" cy="22" r="2.5" fill="#f3d59a" />
          <path
            d="M50 82L50 78"
            stroke="#d9b16f"
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* Gradients */}
          <defs>
            <linearGradient id="mountainGrad" x1="50" y1="32" x2="50" y2="82" gradientUnits="userSpaceOnUse">
              <stop stopColor="#433b47" />
              <stop offset="1" stopColor="#1b1b22" />
            </linearGradient>
            <linearGradient id="goldRidgeGrad" x1="50" y1="22" x2="50" y2="82" gradientUnits="userSpaceOnUse">
              <stop stopColor="#2b2028" />
              <stop offset="0.6" stopColor="#1e1b24" />
              <stop offset="1" stopColor="#121317" />
            </linearGradient>
            <linearGradient id="crystalGrad" x1="50" y1="22" x2="50" y2="78" gradientUnits="userSpaceOnUse">
              <stop stopColor="#f3d59a" />
              <stop offset="0.3" stopColor="#d89a9d" />
              <stop offset="0.75" stopColor="#c57b82" />
              <stop offset="1" stopColor="#7a3641" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Brand Wordmark & Subtitle */}
      <div className="flex flex-col text-left">
        <span
          className={`font-serif-luxury font-bold text-[#f7f3ed] group-hover:text-[#f3d59a] transition-colors leading-tight ${titleSizes[size]}`}
        >
          {BRAND_CONFIG.name}
        </span>
        {showSubtitle && (
          <span className="text-[10px] tracking-[0.24em] font-medium text-[#d9b16f] uppercase mt-0.5">
            {BRAND_CONFIG.headerSubtitle}
          </span>
        )}
      </div>
    </div>
  );
};
