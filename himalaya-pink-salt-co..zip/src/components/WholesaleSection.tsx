import React from 'react';
import { Container, Package, Palette, FileText, ArrowUpRight } from 'lucide-react';

interface WholesaleSectionProps {
  onRequestQuote: () => void;
}

export const WholesaleSection: React.FC<WholesaleSectionProps> = ({ onRequestQuote }) => {
  const wholesaleCards = [
    {
      icon: Container,
      title: 'Bulk Salt Supply',
      description:
        'Supplied in 25kg, 50kg, and 1-ton jumbo bags (FIBC) for food processors, industrial blenders, and repackagers.',
    },
    {
      icon: Package,
      title: 'Retail-Ready Packaging',
      description:
        'Custom cartons, master shipper boxes, and stand-up pouches ready for retail distribution and supermarket shelving.',
    },
    {
      icon: Palette,
      title: 'Custom Packaging Enquiries',
      description:
        'Discussion of buyer-specified materials, custom printing, private labeling, barcodes, and language translations.',
    },
    {
      icon: FileText,
      title: 'Export Documentation Coordination',
      description:
        'Assistance coordinating commercial invoices, packing lists, bill of lading (B/L), and origin certificates for customs clearance.',
    },
  ];

  return (
    <section id="wholesale" className="py-24 bg-[#121317] relative border-t border-b border-[#d9b16f]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-14">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
            <span>GLOBAL B2B DISTRIBUTION</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury text-[#f7f3ed] mb-5 tracking-tight">
            Wholesale Supply. Built Around Your Requirements.
          </h2>
          <p className="text-base sm:text-lg text-[#bdb7b0] font-light leading-relaxed">
            We welcome enquiries from importers, distributors, retailers, food businesses, and
            international trading companies looking for Pakistani Himalayan pink salt.
          </p>
        </div>

        {/* Featured Warehouse & Logistics Media Banner */}
        <div className="relative rounded-sm overflow-hidden border border-[#d9b16f]/30 mb-12 group">
          <div className="aspect-[16/9] md:aspect-[21/9] w-full bg-[#1b1b20]">
            <img
              src="/src/assets/images/bulk_salt_export_packaging_1792434907734.jpg"
              alt="Export-ready wholesale Himalayan pink salt in 25kg sacks and palletized cartons in logistics facility"
              className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-103"
              referrerPolicy="no-referrer"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d] via-[#090a0d]/40 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div className="max-w-xl">
                <span className="text-[11px] uppercase tracking-[0.2em] text-[#d9b16f] font-semibold block mb-1">
                  PALLETIZED CONTAINER LOADS
                </span>
                <p className="text-sm sm:text-base text-[#f7f3ed] font-light">
                  Standard 20ft and 40ft container freight logistics coordinated with international maritime lines.
                </p>
              </div>
              <button
                onClick={onRequestQuote}
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#d9b16f] hover:bg-[#f3d59a] text-[#090a0d] text-xs font-semibold uppercase tracking-wider rounded-sm transition-all shadow-lg shrink-0 cursor-pointer"
              >
                <span>Request a Wholesale Quote</span>
                <ArrowUpRight className="w-4 h-4 text-[#090a0d]" />
              </button>
            </div>
          </div>
        </div>

        {/* 4 Information Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {wholesaleCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className="bg-[#1b1b20] p-6 rounded-sm border border-white/5 hover:border-[#d9b16f]/40 transition-all duration-300 group"
              >
                <div className="w-10 h-10 rounded-sm bg-[#121317] border border-[#d9b16f]/30 flex items-center justify-center text-[#d9b16f] mb-4 group-hover:border-[#d9b16f] group-hover:text-[#f3d59a] transition-colors">
                  <Icon className="w-5 h-5 stroke-[1.5]" />
                </div>
                <h3 className="font-serif-luxury text-lg font-semibold text-[#f7f3ed] mb-2 group-hover:text-[#f3d59a] transition-colors">
                  {card.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#bdb7b0] font-light leading-relaxed">
                  {card.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Responsible Commercial Disclaimer Note */}
        <div className="p-4 sm:p-5 bg-[#090a0d]/60 border border-[#d9b16f]/20 rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#bdb7b0]">
          <p className="leading-relaxed">
            <strong className="text-[#f7f3ed] font-medium">Commercial Notice:</strong> Order quantities, product
            specifications, packaging configurations, pricing, and shipping arrangements (FOB / CIF / CFR) are confirmed
            individually based on destination port and current production scheduling.
          </p>
          <button
            onClick={onRequestQuote}
            className="text-xs text-[#d9b16f] hover:text-[#f3d59a] font-semibold whitespace-nowrap underline underline-offset-4 cursor-pointer"
          >
            Start Wholesale Inquiry →
          </button>
        </div>
      </div>
    </section>
  );
};
