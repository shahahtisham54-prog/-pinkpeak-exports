import React from 'react';
import { MessageCircle } from 'lucide-react';
import { BRAND_CONFIG } from '../config/brand';

interface WhatsAppButtonProps {
  customNumber?: string;
}

export const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({ customNumber }) => {
  const activeNumber = (customNumber || BRAND_CONFIG.whatsAppNumber || '').trim();

  // Rule 13: If no verified business number is configured, hide the floating WhatsApp button
  if (!activeNumber) {
    return null;
  }

  // Sanitize number (digits only)
  const sanitizedNumber = activeNumber.replace(/\D/g, '');

  const encodedMessage = encodeURIComponent(BRAND_CONFIG.whatsAppPrefillMessage);
  const whatsappUrl = `https://wa.me/${sanitizedNumber}?text=${encodedMessage}`;

  return (
    <aside aria-label="Direct trade messaging">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2.5 px-4 py-3 bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-full shadow-[0_4px_24px_rgba(37,211,102,0.4)] transition-all duration-300 hover:scale-105 group"
        aria-label="Direct WhatsApp Export Chat with Himalaya Pink Salt Co."
      >
        <MessageCircle className="w-5 h-5 text-white fill-white" />
        <span className="text-xs font-semibold tracking-wide hidden sm:inline-block">
          Export WhatsApp Desk
        </span>
      </a>
    </aside>
  );
};
