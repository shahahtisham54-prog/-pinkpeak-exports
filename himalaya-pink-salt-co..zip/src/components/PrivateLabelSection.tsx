import React from 'react';
import { Package, Sparkles, Box, CheckCircle } from 'lucide-react';

interface PrivateLabelSectionProps {
  onDiscussPackaging: () => void;
}

export const PrivateLabelSection: React.FC<PrivateLabelSectionProps> = ({ onDiscussPackaging }) => {
  const packagingOptions = [
    {
      title: 'Retail Pouches',
      subtitle: '250g, 500g, 1000g Stand-up Pouches',
      description:
        'Resealable kraft paper, matte black, or frosted window pouches suited for organic retailers and supermarket aisles.',
      icon: Package,
    },
    {
      title: 'Jars and Containers',
      subtitle: 'Glass Grinders & Table Shakers',
      description:
        'High-clarity glass spice jars equipped with adjustable ceramic grinding mechanisms, gold or black metal caps, and tamper seals.',
      icon: Sparkles,
    },
    {
      title: 'Bulk and Food-Service Packaging',
      subtitle: '5kg, 10kg, 25kg Food Service Pails & Sacks',
      description:
        'Durable foodservice buckets and heavy-duty poly-lined export sacks with customer-customized labelling and nutrition panels.',
      icon: Box,
    },
  ];

  return (
    <section id="private-label" className="py-24 bg-[#090a0d] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Editorial Copy & Options */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
              <span className="w-5 h-[1px] bg-[#d9b16f]" />
              <span>OEM & PRIVATE LABEL EXPORT</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury text-[#f7f3ed] mb-6 tracking-tight leading-[1.15]">
              Your Brand. Our Salt. <br />
              <span className="italic text-[#f3d59a]">Your Market.</span>
            </h2>

            <p className="text-base text-[#bdb7b0] font-light leading-relaxed mb-8">
              Planning to launch your own Himalayan pink salt brand? Discuss private-label packaging,
              product formats, branding requirements, and order quantities with us.
            </p>

            {/* 3 Packaging Formats */}
            <div className="space-y-4 mb-8">
              {packagingOptions.map((opt, i) => {
                const Icon = opt.icon;
                return (
                  <div
                    key={i}
                    className="p-5 bg-[#121317] border border-[#d9b16f]/20 hover:border-[#d9b16f]/50 rounded-sm transition-all duration-300 group"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-9 h-9 rounded-sm bg-[#1b1b20] border border-[#d9b16f]/30 flex items-center justify-center text-[#d9b16f] shrink-0 mt-0.5">
                        <Icon className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex flex-wrap items-baseline gap-2 mb-1">
                          <h4 className="text-base font-serif-luxury font-semibold text-[#f7f3ed] group-hover:text-[#f3d59a] transition-colors">
                            {opt.title}
                          </h4>
                          <span className="text-xs text-[#d89a9d]">({opt.subtitle})</span>
                        </div>
                        <p className="text-xs sm:text-sm text-[#bdb7b0] font-light leading-relaxed">
                          {opt.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Commercial Availability Notice */}
            <div className="p-4 bg-[#1b1b20]/60 border border-white/5 rounded-sm mb-8 text-xs text-[#bdb7b0] space-y-1">
              <div className="flex items-center gap-2 text-[#d9b16f] font-medium">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>Customization Requirements</span>
              </div>
              <p>
                Final packaging designs, cylinder printing, custom branding artwork, minimum order quantities
                (MOQs), and production lead times require mutual confirmation prior to order acceptance.
              </p>
            </div>

            <button
              onClick={onDiscussPackaging}
              className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.14em] text-[#090a0d] bg-gradient-to-r from-[#d9b16f] via-[#f3d59a] to-[#d9b16f] hover:brightness-105 transition-all rounded-sm shadow-md cursor-pointer"
            >
              <span>Discuss Your Packaging Requirements</span>
            </button>
          </div>

          {/* Right Column: High-End Mockup Image */}
          <div className="lg:col-span-5">
            <div className="relative rounded-sm overflow-hidden border border-[#d9b16f]/35 p-2 bg-[#121317] group">
              <div className="relative aspect-[4/5] overflow-hidden rounded-sm bg-[#1b1b20]">
                <img
                  src="/src/assets/images/private_label_salt_packaging_1792434907377.jpg"
                  alt="High-end private label Himalayan pink salt pouch with window, glass grinder jar with champagne gold cap, and luxury box"
                  className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d]/90 via-[#090a0d]/20 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <span className="text-[10px] uppercase tracking-[0.22em] text-[#d9b16f] font-medium block mb-1">
                    BESPOKE BRANDING POSSIBILITIES
                  </span>
                  <p className="text-xs text-[#f7f3ed]/90 font-light">
                    Illustrative packaging concepts showcasing pouch finishes, grinder closures, and retail boxing options.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
