import React from 'react';
import { Mountain, PackageCheck, Layers, Sparkles } from 'lucide-react';

export const TrustHighlights: React.FC = () => {
  const highlights = [
    {
      icon: Mountain,
      title: 'Pakistan Origin',
      description: 'Himalayan pink salt sourced from Pakistan.',
    },
    {
      icon: PackageCheck,
      title: 'Flexible Packaging',
      description: 'Packaging options discussed according to product and order requirements.',
    },
    {
      icon: Layers,
      title: 'Wholesale Enquiries',
      description: 'Bulk supply enquiries for importers and distributors.',
    },
    {
      icon: Sparkles,
      title: 'Private Label Options',
      description: 'Explore custom packaging and branding possibilities.',
    },
  ];

  return (
    <section className="relative z-20 -mt-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        {highlights.map((item, index) => {
          const Icon = item.icon;
          return (
            <div
              key={index}
              className="bg-[#1b1b20]/90 backdrop-blur-md border border-[#d9b16f]/25 hover:border-[#d9b16f]/60 p-6 rounded-sm transition-all duration-300 group hover:-translate-y-1 hover:shadow-[0_8px_30px_rgba(217,177,111,0.12)]"
            >
              <div className="flex items-center gap-4 mb-3.5">
                <div className="w-10 h-10 rounded-sm bg-[#121317] border border-[#d9b16f]/30 flex items-center justify-center text-[#d9b16f] group-hover:text-[#f3d59a] group-hover:border-[#d9b16f] transition-colors">
                  <Icon className="w-5 h-5 stroke-[1.5]" />
                </div>
                <h3 className="font-serif-luxury text-lg font-semibold text-[#f7f3ed] group-hover:text-[#f3d59a] transition-colors">
                  {item.title}
                </h3>
              </div>
              <p className="text-xs sm:text-[13px] text-[#bdb7b0] leading-relaxed">
                {item.description}
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
};
