import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface FeaturedGalleryProps {
  onSelectProductForQuote: (productName: string) => void;
}

export const FeaturedGallery: React.FC<FeaturedGalleryProps> = ({ onSelectProductForQuote }) => {
  const galleryItems = [
    {
      title: 'Natural Himalayan Pink Salt Crystals',
      category: 'Geological Harvest',
      description:
        'Pristine, mineral-striated crystal rocks hand-selected from the Khewra and Kalabagh sub-Himalayan formations.',
      image: '/src/assets/images/food_grade_pink_salt_crystals_1792434902437.jpg',
      enquiryTarget: 'Food-Grade Pink Salt',
      buttonLabel: 'Enquire on Crystals',
    },
    {
      title: 'Premium Pink Salt Retail Packaging',
      category: 'Private Label & Retail',
      description:
        'Refined shelf-ready pouches and precision spice grinder glass jars curated for gourmet international retailers.',
      image: '/src/assets/images/private_label_salt_packaging_1792434907377.jpg',
      enquiryTarget: 'Custom-Branded Pink Salt',
      buttonLabel: 'Enquire on Packaging',
    },
    {
      title: 'Illuminated Himalayan Salt Lamps',
      category: 'Artisanal Decor',
      description:
        'Hand-chiseled crystal monoliths emitting a warm ambient amber and peach glow for home decor and wellness markets.',
      image: '/src/assets/images/illuminated_salt_lamps_1792434905482.jpg',
      enquiryTarget: 'Pink Salt Lamps',
      buttonLabel: 'Enquire on Salt Lamps',
    },
  ];

  return (
    <section className="py-24 bg-[#121317] relative border-t border-b border-[#d9b16f]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
            <span>VISUAL PORTFOLIO</span>
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury text-[#f7f3ed] mb-4 tracking-tight">
            Curated Mineral Impressions
          </h2>
          <p className="text-base text-[#bdb7b0] font-light leading-relaxed">
            Witness the natural distinction and craftsmanship of Pakistani pink salt in diverse commercial expressions.
          </p>
        </div>

        {/* 3 Large Image Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {galleryItems.map((item, idx) => (
            <div
              key={idx}
              className="bg-[#1b1b20] rounded-sm overflow-hidden border border-[#d9b16f]/25 hover:border-[#d9b16f]/70 transition-all duration-500 group flex flex-col justify-between"
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-[#090a0d]">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-108"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1b1b20] via-black/30 to-transparent opacity-85" />

                <div className="absolute top-4 left-4">
                  <span className="text-[10px] uppercase tracking-widest text-[#d9b16f] font-medium px-2.5 py-1 rounded-sm bg-[#090a0d]/85 backdrop-blur-sm border border-[#d9b16f]/25">
                    {item.category}
                  </span>
                </div>
              </div>

              <div className="p-7 flex-1 flex flex-col justify-between">
                <div>
                  {/* Subtle gold divider on hover */}
                  <div className="w-8 h-[1.5px] bg-[#d9b16f]/40 group-hover:w-16 group-hover:bg-[#d9b16f] transition-all duration-300 mb-4" />

                  <h3 className="font-serif-luxury text-2xl font-semibold text-[#f7f3ed] group-hover:text-[#f3d59a] transition-colors mb-3 leading-snug">
                    {item.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#bdb7b0] font-light leading-relaxed mb-6">
                    {item.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/5">
                  <button
                    onClick={() => onSelectProductForQuote(item.enquiryTarget)}
                    className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#d9b16f] hover:text-[#f3d59a] transition-colors cursor-pointer group/link"
                  >
                    <span>{item.buttonLabel}</span>
                    <ArrowUpRight className="w-4 h-4 transition-transform group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
