import React from 'react';

export const ExportProcess: React.FC = () => {
  const steps = [
    {
      step: '01',
      title: 'Share Your Requirements',
      description:
        'Tell us your destination country, product type, quantity, and packaging preferences.',
    },
    {
      step: '02',
      title: 'Confirm Specifications',
      description:
        'Discuss the product grade, packaging format, documentation requirements, and commercial details.',
    },
    {
      step: '03',
      title: 'Review the Quotation',
      description:
        'Receive a quotation based on confirmed product specifications, quantities, shipping arrangements, and agreed commercial terms.',
    },
    {
      step: '04',
      title: 'Plan the Order',
      description:
        'After both parties agree on the terms, coordinate the appropriate payment, supply, documentation, and shipment arrangements.',
    },
  ];

  return (
    <section className="py-24 bg-[#090a0d] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
            <span>TRANSPARENT EXPORT WORKFLOW</span>
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury text-[#f7f3ed] mb-4 tracking-tight">
            How the Export Enquiry Process Works
          </h2>
          <p className="text-base text-[#bdb7b0] font-light leading-relaxed">
            A structured, collaborative approach ensuring accurate specifications and dependable commercial agreements.
          </p>
        </div>

        {/* 4 Steps with connecting lines */}
        <div className="relative">
          {/* Subtle horizontal connecting line on desktop */}
          <div className="hidden lg:block absolute top-12 left-16 right-16 h-[1px] bg-gradient-to-r from-transparent via-[#d9b16f]/30 to-transparent z-0" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {steps.map((item, idx) => (
              <div
                key={idx}
                className="bg-[#121317] border border-[#d9b16f]/20 hover:border-[#d9b16f]/60 p-7 rounded-sm flex flex-col justify-between transition-all duration-300 group hover:-translate-y-1 hover:shadow-xl"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-serif-luxury text-3xl font-bold text-[#d9b16f] group-hover:text-[#f3d59a] transition-colors">
                      {item.step}
                    </span>
                    <span className="text-[10px] uppercase tracking-widest text-[#d89a9d] font-medium px-2 py-0.5 rounded-sm bg-[#1b1b20]">
                      Phase {idx + 1}
                    </span>
                  </div>

                  <h3 className="font-serif-luxury text-xl font-semibold text-[#f7f3ed] mb-3 group-hover:text-[#f3d59a] transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#bdb7b0] font-light leading-relaxed">
                    “{item.description}”
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/5 text-[11px] text-[#d9b16f]/80">
                  Step {idx + 1} of 4
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
