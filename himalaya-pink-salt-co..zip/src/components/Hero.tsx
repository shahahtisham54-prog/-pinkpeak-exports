import React from 'react';
import { ArrowRight, Compass, ShieldCheck } from 'lucide-react';

interface HeroProps {
  onExploreProducts: () => void;
  onRequestWholesale: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreProducts, onRequestWholesale }) => {
  return (
    <section id="hero" className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 overflow-hidden">
      {/* Cinematic Background Image with Multi-layered Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_himalayan_salt_landscape_1792434901533.jpg"
          alt="Natural Himalayan pink salt crystals in foreground with Pakistan Salt Range mountains at sunset"
          className="w-full h-full object-cover object-center scale-105 transform motion-safe:animate-fade-in"
          referrerPolicy="no-referrer"
        />
        {/* Gradients ensuring WCAG contrast and luxury mood */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d] via-[#090a0d]/75 to-[#090a0d]/45" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#090a0d]/90 via-[#090a0d]/50 to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(216,154,157,0.18),transparent_50%)]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-8">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <div className="inline-flex items-center gap-2 mb-6 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
            <span className="w-6 h-[1.5px] bg-[#d9b16f]" />
            <span>PREMIUM PAKISTANI HIMALAYAN PINK SALT</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif-luxury font-normal tracking-tight text-[#f7f3ed] leading-[1.08] mb-6">
            Pure Himalayan Pink Salt.
            <span className="block italic text-[#f3d59a] font-normal mt-2 text-3xl sm:text-4xl md:text-5xl lg:text-6xl">
              Naturally Distinct. Globally Delivered.
            </span>
          </h1>

          {/* Description */}
          <p className="text-base sm:text-lg text-[#bdb7b0] leading-relaxed mb-8 max-w-2xl font-light">
            Discover premium Himalayan pink salt sourced from Pakistan, with product options for food,
            wellness, decorative applications, wholesale distribution, and private-label brands.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mb-10">
            <button
              onClick={onExploreProducts}
              className="inline-flex items-center justify-center gap-2.5 px-7 py-4 text-xs font-semibold uppercase tracking-[0.14em] text-[#090a0d] bg-gradient-to-r from-[#d9b16f] via-[#f3d59a] to-[#d9b16f] hover:brightness-105 transition-all duration-300 rounded-sm shadow-[0_4px_24px_rgba(217,177,111,0.35)] cursor-pointer"
            >
              <span>Explore Our Products</span>
              <ArrowRight className="w-4 h-4 text-[#090a0d]" />
            </button>

            <button
              onClick={onRequestWholesale}
              className="inline-flex items-center justify-center gap-2 px-7 py-4 text-xs font-semibold uppercase tracking-[0.14em] text-[#f7f3ed] bg-[#1b1b20]/80 hover:bg-[#1b1b20] border border-[#d9b16f]/40 hover:border-[#d9b16f] transition-all duration-300 rounded-sm backdrop-blur-sm cursor-pointer"
            >
              <span>Request Wholesale Pricing</span>
            </button>
          </div>

          {/* Subtle Trust Line */}
          <div className="pt-6 border-t border-[#d9b16f]/20 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs tracking-wider text-[#bdb7b0]">
            <div className="flex items-center gap-2">
              <Compass className="w-3.5 h-3.5 text-[#d9b16f]" />
              <span className="text-[#f7f3ed]">Pakistan Origin</span>
            </div>
            <span className="text-[#d9b16f]/50">·</span>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-[#d9b16f]" />
              <span className="text-[#f7f3ed]">Wholesale Supply</span>
            </div>
            <span className="text-[#d9b16f]/50">·</span>
            <div className="text-[#d89a9d]">Export Enquiries Welcome</div>
          </div>
        </div>
      </div>
    </section>
  );
};
