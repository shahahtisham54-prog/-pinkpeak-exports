import React, { useState, useEffect } from 'react';
import { X, Send, CheckCircle2, AlertCircle, Building2, Mail, Globe, User } from 'lucide-react';
import { BRAND_CONFIG } from '../config/brand';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultProduct?: string;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  isOpen,
  onClose,
  defaultProduct = 'Food-Grade Pink Salt',
}) => {
  const [formData, setFormData] = useState({
    fullName: '',
    businessName: '',
    businessEmail: '',
    destinationCountry: '',
    productOfInterest: defaultProduct,
    estimatedQuantity: '20ft FCL Container (Approx. 24 - 26 Metric Tons)',
    packagingPreference: '25 kg Multi-Wall Woven PP / PE Bags',
    additionalRequirements: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (defaultProduct) {
      setFormData((prev) => ({ ...prev, productOfInterest: defaultProduct }));
    }
  }, [defaultProduct]);

  if (!isOpen) return null;

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.fullName.trim()) errs.fullName = 'Full Name is required.';
    if (!formData.businessName.trim()) errs.businessName = 'Business Name is required.';
    if (!formData.businessEmail.trim()) {
      errs.businessEmail = 'Business Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.businessEmail)) {
      errs.businessEmail = 'Please provide a valid email address.';
    }
    if (!formData.destinationCountry.trim()) errs.destinationCountry = 'Destination Country is required.';
    if (!formData.additionalRequirements.trim()) errs.additionalRequirements = 'Please specify order details.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    const endpoint = (import.meta as any).env?.VITE_CONTACT_FORM_ENDPOINT || '';

    try {
      if (endpoint) {
        await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...formData,
            submittedAt: new Date().toISOString(),
            source: 'Modal Fast Quote',
          }),
        });
      } else {
        const subject = encodeURIComponent(`Fast Quote: ${formData.productOfInterest} - ${formData.businessName}`);
        const bodyContent =
          `EXPORT FAST QUOTE - HIMALAYA PINK SALT CO.\n\n` +
          `Name: ${formData.fullName}\n` +
          `Company: ${formData.businessName}\n` +
          `Email: ${formData.businessEmail}\n` +
          `Destination: ${formData.destinationCountry}\n` +
          `Product: ${formData.productOfInterest}\n` +
          `Estimated Quantity: ${formData.estimatedQuantity}\n` +
          `Packaging: ${formData.packagingPreference}\n\n` +
          `Requirements:\n${formData.additionalRequirements}`;

        window.location.href = `mailto:${BRAND_CONFIG.contactEmail}?subject=${subject}&body=${encodeURIComponent(
          bodyContent
        )}`;
      }
      setIsSuccess(true);
    } catch (err) {
      console.error(err);
      window.location.href = `mailto:${BRAND_CONFIG.contactEmail}`;
      setIsSuccess(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#121317] border border-[#d9b16f]/40 rounded-sm max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#bdb7b0] hover:text-[#f7f3ed] p-1.5 rounded-sm hover:bg-white/5 transition-colors"
          aria-label="Close quote modal"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="py-8 text-center">
            <div className="w-14 h-14 rounded-full bg-[#1b1b20] border border-[#d9b16f] text-[#d9b16f] flex items-center justify-center mx-auto mb-5">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h3 className="font-serif-luxury text-2xl font-semibold text-[#f7f3ed] mb-2">
              Quotation Request Prepared
            </h3>
            <p className="text-sm text-[#bdb7b0] max-w-md mx-auto mb-6">
              Thank you for sharing your commercial export requirements. Our sales coordination team will review
              your specifications and prepare a formal proforma response.
            </p>
            <button
              onClick={() => {
                setIsSuccess(false);
                onClose();
              }}
              className="px-6 py-2.5 bg-[#d9b16f] text-[#090a0d] text-xs font-semibold uppercase tracking-wider rounded-sm cursor-pointer"
            >
              Close Window
            </button>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-2 mb-2 text-xs uppercase tracking-widest text-[#d9b16f] font-semibold">
              <span>COMMERCIAL PROFORMA REQUEST</span>
            </div>
            <h3 className="text-2xl font-serif-luxury font-semibold text-[#f7f3ed] mb-2">
              Request Export Quotation
            </h3>
            <p className="text-xs sm:text-sm text-[#bdb7b0] mb-6 font-light">
              Submit your destination and volume specifications for a tailored B2B export offer.
            </p>

            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-[#f7f3ed] font-medium mb-1.5">
                    Full Name *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-4 h-4 text-[#bdb7b0]" />
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      placeholder="Your name"
                      className="w-full bg-[#1b1b20] text-[#f7f3ed] pl-9 pr-3 py-2.5 text-xs rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] focus:outline-none"
                    />
                  </div>
                  {errors.fullName && <p className="text-[11px] text-red-400 mt-1">{errors.fullName}</p>}
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-[#f7f3ed] font-medium mb-1.5">
                    Company Name *
                  </label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-3 w-4 h-4 text-[#bdb7b0]" />
                    <input
                      type="text"
                      value={formData.businessName}
                      onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                      placeholder="Your company"
                      className="w-full bg-[#1b1b20] text-[#f7f3ed] pl-9 pr-3 py-2.5 text-xs rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] focus:outline-none"
                    />
                  </div>
                  {errors.businessName && <p className="text-[11px] text-red-400 mt-1">{errors.businessName}</p>}
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-[#f7f3ed] font-medium mb-1.5">
                    Business Email *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 w-4 h-4 text-[#bdb7b0]" />
                    <input
                      type="email"
                      value={formData.businessEmail}
                      onChange={(e) => setFormData({ ...formData, businessEmail: e.target.value })}
                      placeholder="buyer@company.com"
                      className="w-full bg-[#1b1b20] text-[#f7f3ed] pl-9 pr-3 py-2.5 text-xs rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] focus:outline-none"
                    />
                  </div>
                  {errors.businessEmail && <p className="text-[11px] text-red-400 mt-1">{errors.businessEmail}</p>}
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-[#f7f3ed] font-medium mb-1.5">
                    Destination Country *
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-3 w-4 h-4 text-[#bdb7b0]" />
                    <input
                      type="text"
                      value={formData.destinationCountry}
                      onChange={(e) => setFormData({ ...formData, destinationCountry: e.target.value })}
                      placeholder="e.g. United Kingdom"
                      className="w-full bg-[#1b1b20] text-[#f7f3ed] pl-9 pr-3 py-2.5 text-xs rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] focus:outline-none"
                    />
                  </div>
                  {errors.destinationCountry && (
                    <p className="text-[11px] text-red-400 mt-1">{errors.destinationCountry}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-[#f7f3ed] font-medium mb-1.5">
                    Product *
                  </label>
                  <select
                    value={formData.productOfInterest}
                    onChange={(e) => setFormData({ ...formData, productOfInterest: e.target.value })}
                    className="w-full bg-[#1b1b20] text-[#f7f3ed] px-3 py-2.5 text-xs rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] focus:outline-none cursor-pointer"
                  >
                    {[
                      'Food-Grade Pink Salt',
                      'Fine or Coarse Pink Salt',
                      'Pink Salt Chunks',
                      'Pink Salt Lamps',
                      'Pink Salt Cooking Blocks',
                      'Private Label Products',
                      'Bulk Supply',
                      'Other',
                    ].map((p) => (
                      <option key={p} value={p} className="bg-[#121317]">
                        {p}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] uppercase tracking-wider text-[#f7f3ed] font-medium mb-1.5">
                    Estimated Quantity *
                  </label>
                  <select
                    value={formData.estimatedQuantity}
                    onChange={(e) => setFormData({ ...formData, estimatedQuantity: e.target.value })}
                    className="w-full bg-[#1b1b20] text-[#f7f3ed] px-3 py-2.5 text-xs rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] focus:outline-none cursor-pointer"
                  >
                    {BRAND_CONFIG.orderQuantities.map((q) => (
                      <option key={q} value={q} className="bg-[#121317]">
                        {q}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] uppercase tracking-wider text-[#f7f3ed] font-medium mb-1.5">
                  Packaging & Requirements *
                </label>
                <textarea
                  rows={3}
                  value={formData.additionalRequirements}
                  onChange={(e) => setFormData({ ...formData, additionalRequirements: e.target.value })}
                  placeholder="Detail preferred grain sizes, packaging format (25kg bags, pouches, jars), target port, and delivery schedule..."
                  className="w-full bg-[#1b1b20] text-[#f7f3ed] p-3 text-xs rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] focus:outline-none"
                />
                {errors.additionalRequirements && (
                  <p className="text-[11px] text-red-400 mt-1">{errors.additionalRequirements}</p>
                )}
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 text-xs text-[#bdb7b0] hover:text-[#f7f3ed] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-[#d9b16f] to-[#f3d59a] text-[#090a0d] text-xs font-semibold uppercase tracking-wider rounded-sm shadow-md cursor-pointer disabled:opacity-50"
                >
                  <span>{isSubmitting ? 'Sending...' : 'Submit Quote Request'}</span>
                  <Send className="w-3.5 h-3.5 text-[#090a0d]" />
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
