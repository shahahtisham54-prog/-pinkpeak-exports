import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface NavbarProps {
  onRequestQuote: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onRequestQuote }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#hero' },
    { label: 'Our Products', href: '#products' },
    { label: 'Wholesale & Bulk', href: '#wholesale' },
    { label: 'Private Label', href: '#private-label' },
    { label: 'About Pakistan Salt', href: '#about-salt' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#090a0d]/90 backdrop-blur-md border-b border-[#d9b16f]/20 py-3 shadow-2xl'
          : 'bg-gradient-to-b from-[#090a0d]/80 via-[#090a0d]/40 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6">
          {/* Brand Identity Lockup */}
          <a
            href="#hero"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('#hero');
            }}
            className="flex items-center group transition-opacity hover:opacity-95"
            aria-label="Himalaya Pink Salt Co. Home"
          >
            <BrandLogo size="md" showSubtitle={true} />
          </a>

          {/* Desktop Navigation Links */}
          <nav
            aria-label="Main Navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-[#bdb7b0]"
          >
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className="relative py-1 hover:text-[#f7f3ed] transition-colors whitespace-nowrap group text-[13px] tracking-wide"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1.5px] bg-[#d9b16f] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Right Action: Gold CTA */}
          <div className="hidden sm:flex items-center gap-4 shrink-0">
            <button
              onClick={onRequestQuote}
              className="relative inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-[0.12em] text-[#090a0d] bg-gradient-to-r from-[#d9b16f] via-[#f3d59a] to-[#d9b16f] bg-[length:200%_auto] hover:bg-[position:right_center] rounded-sm transition-all duration-300 shadow-[0_2px_14px_rgba(217,177,111,0.25)] hover:shadow-[0_4px_22px_rgba(217,177,111,0.4)] active:scale-[0.98] cursor-pointer"
            >
              <span>Request a Quote</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#090a0d]" />
            </button>
          </div>

          {/* Mobile Menu Trigger */}
          <div className="flex md:hidden items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#f7f3ed] hover:text-[#d9b16f] focus:outline-none focus:ring-1 focus:ring-[#d9b16f] rounded border border-white/10"
              aria-expanded={mobileMenuOpen}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0e0f14]/98 backdrop-blur-xl border-b border-[#d9b16f]/25 px-6 pt-5 pb-8 animate-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className="text-base font-medium text-[#bdb7b0] hover:text-[#f3d59a] py-2 border-b border-white/5 transition-colors"
              >
                {link.label}
              </a>
            ))}

            <div className="pt-4 flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onRequestQuote();
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-[#090a0d] bg-gradient-to-r from-[#d9b16f] to-[#f3d59a] rounded-sm shadow-md"
              >
                <span>Request a Quote</span>
                <ArrowUpRight className="w-4 h-4 text-[#090a0d]" />
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
