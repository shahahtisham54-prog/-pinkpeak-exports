import React, { useState, useEffect } from 'react';
import { Send, CheckCircle2, AlertCircle, Mail, Globe, MapPin, Building2, User } from 'lucide-react';
import { BRAND_CONFIG } from '../config/brand';

interface EnquiryFormProps {
  initialProduct?: string;
  onSuccess?: () => void;
}

export const EnquiryForm: React.FC<EnquiryFormProps> = ({ initialProduct = '', onSuccess }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    businessName: '',
    businessEmail: '',
    destinationCountry: '',
    productOfInterest: initialProduct || 'Food-Grade Pink Salt',
    estimatedQuantity: '20ft FCL Container (Approx. 24 - 26 Metric Tons)',
    packagingPreference: '25 kg Multi-Wall Woven PP / PE Bags',
    additionalRequirements: '',
    phoneWhatsapp: '',
    website: '',
    targetDeliveryPort: '',
    shippingTerms: 'FOB (Free on Board)',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitStatusMessage, setSubmitStatusMessage] = useState<string | null>(null);

  // Sync when initialProduct prop changes
  useEffect(() => {
    if (initialProduct) {
      setFormData((prev) => ({ ...prev, productOfInterest: initialProduct }));
    }
  }, [initialProduct]);

  const productOptions = [
    'Food-Grade Pink Salt',
    'Fine or Coarse Pink Salt',
    'Pink Salt Chunks',
    'Pink Salt Lamps',
    'Pink Salt Cooking Blocks',
    'Private Label Products',
    'Bulk Supply',
    'Other',
  ];

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full Name is required.';
    }
    if (!formData.businessName.trim()) {
      newErrors.businessName = 'Business Name is required.';
    }

    if (!formData.businessEmail.trim()) {
      newErrors.businessEmail = 'Business Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.businessEmail)) {
      newErrors.businessEmail = 'Please provide a valid business email address.';
    }

    if (!formData.destinationCountry.trim()) {
      newErrors.destinationCountry = 'Destination Country is required for export calculations.';
    }

    if (!formData.productOfInterest) {
      newErrors.productOfInterest = 'Please select a product of interest.';
    }

    if (!formData.estimatedQuantity) {
      newErrors.estimatedQuantity = 'Please select estimated order quantity.';
    }

    if (!formData.packagingPreference) {
      newErrors.packagingPreference = 'Please select your packaging preference.';
    }

    if (!formData.additionalRequirements.trim()) {
      newErrors.additionalRequirements = 'Please specify your order or commercial requirements.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) {
      return;
    }

    setIsSubmitting(true);
    setSubmitStatusMessage(null);

    const endpoint = (import.meta as any).env?.VITE_CONTACT_FORM_ENDPOINT || '';

    try {
      if (endpoint) {
        // Send to configured backend endpoint
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...formData,
            submittedAt: new Date().toISOString(),
            source: 'Himalaya Pink Salt Co. Export Web Portal',
          }),
        });

        if (!response.ok) {
          throw new Error(`Server returned ${response.status}`);
        }

        setSubmitSuccess(true);
        setSubmitStatusMessage('Your export enquiry was dispatched directly to our commercial sales desk.');
      } else {
        // Fallback: Honest mailto protocol generation
        const subject = encodeURIComponent(
          `Export Enquiry: ${formData.productOfInterest} - ${formData.businessName} (${formData.destinationCountry})`
        );
        const bodyContent =
          `EXPORT ENQUIRY - HIMALAYA PINK SALT CO.\n\n` +
          `Full Name: ${formData.fullName}\n` +
          `Company / Business: ${formData.businessName}\n` +
          `Email: ${formData.businessEmail}\n` +
          `Phone / WhatsApp: ${formData.phoneWhatsapp || 'Not provided'}\n` +
          `Website: ${formData.website || 'Not provided'}\n` +
          `Destination Country: ${formData.destinationCountry}\n` +
          `Target Delivery Port: ${formData.targetDeliveryPort || 'To be discussed'}\n` +
          `Product of Interest: ${formData.productOfInterest}\n` +
          `Estimated Order Quantity: ${formData.estimatedQuantity}\n` +
          `Packaging Preference: ${formData.packagingPreference}\n` +
          `Preferred Shipping Terms: ${formData.shippingTerms}\n\n` +
          `Detailed Requirements:\n${formData.additionalRequirements}\n\n` +
          `Note: Sent via official web enquiry form fallback.`;

        const mailtoUri = `mailto:${BRAND_CONFIG.contactEmail}?subject=${subject}&body=${encodeURIComponent(
          bodyContent
        )}`;

        // Open email client
        window.location.href = mailtoUri;

        setSubmitSuccess(true);
        setSubmitStatusMessage(
          `Your email client has been prepared with your enquiry details directed to ${BRAND_CONFIG.contactEmail}. Please confirm sending in your email client.`
        );
      }

      if (onSuccess) onSuccess();
    } catch (err: any) {
      console.error('Enquiry dispatch error:', err);
      // Fallback in case fetch fails
      const fallbackSubject = encodeURIComponent(`Export Enquiry - ${formData.businessName}`);
      window.location.href = `mailto:${BRAND_CONFIG.contactEmail}?subject=${fallbackSubject}`;
      setSubmitSuccess(true);
      setSubmitStatusMessage(
        `Direct endpoint connection was unavailable. An email window was initiated for ${BRAND_CONFIG.contactEmail}.`
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmitSuccess(false);
    setSubmitStatusMessage(null);
    setFormData({
      fullName: '',
      businessName: '',
      businessEmail: '',
      destinationCountry: '',
      productOfInterest: 'Food-Grade Pink Salt',
      estimatedQuantity: '20ft FCL Container (Approx. 24 - 26 Metric Tons)',
      packagingPreference: '25 kg Multi-Wall Woven PP / PE Bags',
      additionalRequirements: '',
      phoneWhatsapp: '',
      website: '',
      targetDeliveryPort: '',
      shippingTerms: 'FOB (Free on Board)',
    });
  };

  return (
    <section id="contact" className="py-24 bg-[#090a0d] relative overflow-hidden">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
            <span>EXPORT ENQUIRY DESK</span>
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury text-[#f7f3ed] mb-4 tracking-tight">
            Let's Discuss Your Pink Salt Requirements
          </h2>
          <p className="text-base text-[#bdb7b0] font-light leading-relaxed">
            Tell us what you need, where you plan to import it, and how you would like it packaged.
            We will use these details to prepare an appropriate commercial response.
          </p>
        </div>

        {/* Success Confirmation Card */}
        {submitSuccess ? (
          <div className="bg-[#121317] border border-[#d9b16f]/50 p-8 sm:p-12 rounded-sm text-center animate-in zoom-in-95 duration-300">
            <div className="w-16 h-16 rounded-full bg-[#1b1b20] border border-[#d9b16f] text-[#d9b16f] flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-serif-luxury text-3xl font-semibold text-[#f7f3ed] mb-3">
              Enquiry Details Recorded
            </h3>
            <p className="text-sm sm:text-base text-[#bdb7b0] max-w-xl mx-auto mb-4 font-light leading-relaxed">
              {submitStatusMessage}
            </p>
            <div className="p-4 bg-[#1b1b20] border border-white/5 rounded-sm max-w-lg mx-auto mb-8 text-xs text-[#bdb7b0] text-left space-y-1">
              <div><strong className="text-[#f7f3ed]">Product:</strong> {formData.productOfInterest}</div>
              <div><strong className="text-[#f7f3ed]">Estimated Quantity:</strong> {formData.estimatedQuantity}</div>
              <div><strong className="text-[#f7f3ed]">Destination:</strong> {formData.destinationCountry}</div>
              <div><strong className="text-[#f7f3ed]">Direct Export Desk:</strong> {BRAND_CONFIG.contactEmail}</div>
            </div>
            <p className="text-xs text-[#d89a9d] mb-6 italic">
              Notice: Opening an external email application or submitting this form does not guarantee automatic order acceptance or shipping confirmation until specifications are reviewed.
            </p>
            <button
              onClick={handleReset}
              className="px-8 py-3 bg-[#d9b16f] hover:bg-[#f3d59a] text-[#090a0d] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors cursor-pointer"
            >
              Submit Another Inquiry
            </button>
          </div>
        ) : (
          /* Main Form Card */
          <form
            onSubmit={handleSubmit}
            noValidate
            className="bg-[#121317] border border-[#d9b16f]/30 p-6 sm:p-10 rounded-sm shadow-2xl relative group"
          >
            <div className="text-xs uppercase tracking-wider text-[#d9b16f] font-semibold mb-6 pb-3 border-b border-white/5 flex items-center justify-between">
              <span>Section 1: Commercial Buyer Information</span>
              <span className="text-[#d89a9d] font-normal normal-case">* Required fields</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Full Name */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Full Name <span className="text-[#d89a9d]">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3.5 w-4 h-4 text-[#bdb7b0]" />
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    placeholder="e.g. Alexander Vance"
                    className={`w-full bg-[#1b1b20] text-[#f7f3ed] pl-10 pr-4 py-3 rounded-sm border ${
                      errors.fullName ? 'border-red-400' : 'border-[#d9b16f]/20 focus:border-[#d9b16f]'
                    } text-sm focus:outline-none transition-colors placeholder:text-neutral-500`}
                  />
                </div>
                {errors.fullName && (
                  <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.fullName}
                  </p>
                )}
              </div>

              {/* Business Name */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Business Name <span className="text-[#d89a9d]">*</span>
                </label>
                <div className="relative">
                  <Building2 className="absolute left-3.5 top-3.5 w-4 h-4 text-[#bdb7b0]" />
                  <input
                    type="text"
                    name="businessName"
                    value={formData.businessName}
                    onChange={handleChange}
                    placeholder="e.g. Vance Trading Corp / EuroGourmet GmbH"
                    className={`w-full bg-[#1b1b20] text-[#f7f3ed] pl-10 pr-4 py-3 rounded-sm border ${
                      errors.businessName ? 'border-red-400' : 'border-[#d9b16f]/20 focus:border-[#d9b16f]'
                    } text-sm focus:outline-none transition-colors placeholder:text-neutral-500`}
                  />
                </div>
                {errors.businessName && (
                  <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.businessName}
                  </p>
                )}
              </div>

              {/* Business Email */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Business Email <span className="text-[#d89a9d]">*</span>
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 w-4 h-4 text-[#bdb7b0]" />
                  <input
                    type="email"
                    name="businessEmail"
                    value={formData.businessEmail}
                    onChange={handleChange}
                    placeholder="purchasing@company.com"
                    className={`w-full bg-[#1b1b20] text-[#f7f3ed] pl-10 pr-4 py-3 rounded-sm border ${
                      errors.businessEmail ? 'border-red-400' : 'border-[#d9b16f]/20 focus:border-[#d9b16f]'
                    } text-sm focus:outline-none transition-colors placeholder:text-neutral-500`}
                  />
                </div>
                {errors.businessEmail && (
                  <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.businessEmail}
                  </p>
                )}
              </div>

              {/* Destination Country */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Destination Country <span className="text-[#d89a9d]">*</span>
                </label>
                <div className="relative">
                  <Globe className="absolute left-3.5 top-3.5 w-4 h-4 text-[#bdb7b0]" />
                  <input
                    type="text"
                    name="destinationCountry"
                    value={formData.destinationCountry}
                    onChange={handleChange}
                    placeholder="e.g. United Kingdom, Germany, USA, UAE"
                    className={`w-full bg-[#1b1b20] text-[#f7f3ed] pl-10 pr-4 py-3 rounded-sm border ${
                      errors.destinationCountry ? 'border-red-400' : 'border-[#d9b16f]/20 focus:border-[#d9b16f]'
                    } text-sm focus:outline-none transition-colors placeholder:text-neutral-500`}
                  />
                </div>
                {errors.destinationCountry && (
                  <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.destinationCountry}
                  </p>
                )}
              </div>
            </div>

            <div className="text-xs uppercase tracking-wider text-[#d9b16f] font-semibold mb-6 pb-3 border-b border-white/5">
              <span>Section 2: Product & Logistics Specifications</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Product of Interest */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Product of Interest <span className="text-[#d89a9d]">*</span>
                </label>
                <select
                  name="productOfInterest"
                  value={formData.productOfInterest}
                  onChange={handleChange}
                  className="w-full bg-[#1b1b20] text-[#f7f3ed] px-4 py-3 rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] text-sm focus:outline-none cursor-pointer"
                >
                  {productOptions.map((prod) => (
                    <option key={prod} value={prod} className="bg-[#121317] text-[#f7f3ed]">
                      {prod}
                    </option>
                  ))}
                </select>
              </div>

              {/* Estimated Order Quantity */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Estimated Order Quantity <span className="text-[#d89a9d]">*</span>
                </label>
                <select
                  name="estimatedQuantity"
                  value={formData.estimatedQuantity}
                  onChange={handleChange}
                  className="w-full bg-[#1b1b20] text-[#f7f3ed] px-4 py-3 rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] text-sm focus:outline-none cursor-pointer"
                >
                  {BRAND_CONFIG.orderQuantities.map((qty) => (
                    <option key={qty} value={qty} className="bg-[#121317] text-[#f7f3ed]">
                      {qty}
                    </option>
                  ))}
                </select>
              </div>

              {/* Packaging Preference */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Packaging Preference <span className="text-[#d89a9d]">*</span>
                </label>
                <select
                  name="packagingPreference"
                  value={formData.packagingPreference}
                  onChange={handleChange}
                  className="w-full bg-[#1b1b20] text-[#f7f3ed] px-4 py-3 rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] text-sm focus:outline-none cursor-pointer"
                >
                  {BRAND_CONFIG.exportPackagingTypes.map((pkg) => (
                    <option key={pkg} value={pkg} className="bg-[#121317] text-[#f7f3ed]">
                      {pkg}
                    </option>
                  ))}
                </select>
              </div>

              {/* Preferred Shipping Terms */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Preferred Shipping Terms (Incoterms)
                </label>
                <select
                  name="shippingTerms"
                  value={formData.shippingTerms}
                  onChange={handleChange}
                  className="w-full bg-[#1b1b20] text-[#f7f3ed] px-4 py-3 rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] text-sm focus:outline-none cursor-pointer"
                >
                  {BRAND_CONFIG.acceptedIncoterms.map((term) => (
                    <option key={term} value={term} className="bg-[#121317] text-[#f7f3ed]">
                      {term}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="text-xs uppercase tracking-wider text-[#d9b16f] font-semibold mb-6 pb-3 border-b border-white/5">
              <span>Section 3: Optional Trade Coordinates</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* WhatsApp or Telephone Number */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  WhatsApp / Phone (Optional)
                </label>
                <input
                  type="text"
                  name="phoneWhatsapp"
                  value={formData.phoneWhatsapp}
                  onChange={handleChange}
                  placeholder="+44 7911 123456"
                  className="w-full bg-[#1b1b20] text-[#f7f3ed] px-4 py-3 rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] text-sm focus:outline-none placeholder:text-neutral-500"
                />
              </div>

              {/* Website */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Company Website (Optional)
                </label>
                <input
                  type="text"
                  name="website"
                  value={formData.website}
                  onChange={handleChange}
                  placeholder="https://yourcompany.com"
                  className="w-full bg-[#1b1b20] text-[#f7f3ed] px-4 py-3 rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] text-sm focus:outline-none placeholder:text-neutral-500"
                />
              </div>

              {/* Target Delivery Port */}
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                  Target Delivery Port (Optional)
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3.5 top-3.5 w-4 h-4 text-[#bdb7b0]" />
                  <input
                    type="text"
                    name="targetDeliveryPort"
                    value={formData.targetDeliveryPort}
                    onChange={handleChange}
                    placeholder="e.g. Hamburg, Felixstowe, Houston"
                    className="w-full bg-[#1b1b20] text-[#f7f3ed] pl-10 pr-4 py-3 rounded-sm border border-[#d9b16f]/20 focus:border-[#d9b16f] text-sm focus:outline-none placeholder:text-neutral-500"
                  />
                </div>
              </div>
            </div>

            {/* Additional Requirements */}
            <div className="mb-8">
              <label className="block text-xs uppercase tracking-wider text-[#f7f3ed] font-medium mb-2">
                Additional Requirements <span className="text-[#d89a9d]">*</span>
              </label>
              <textarea
                name="additionalRequirements"
                rows={4}
                value={formData.additionalRequirements}
                onChange={handleChange}
                placeholder="Please outline mesh sizing requirements, private label artwork status, target delivery schedules, or palletizing preferences..."
                className={`w-full bg-[#1b1b20] text-[#f7f3ed] p-4 rounded-sm border ${
                  errors.additionalRequirements ? 'border-red-400' : 'border-[#d9b16f]/20 focus:border-[#d9b16f]'
                } text-sm focus:outline-none transition-colors placeholder:text-neutral-500`}
              />
              {errors.additionalRequirements && (
                <p className="mt-1 text-xs text-red-400 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> {errors.additionalRequirements}
                </p>
              )}
            </div>

            {/* Submission Button and Notice */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pt-6 border-t border-white/5">
              <div className="text-xs text-[#bdb7b0] max-w-md font-light">
                Submitted details are used solely to draft an export proforma quotation. No automated
                charges or binding delivery agreements occur until proforma terms are finalized.
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-9 py-4 text-xs font-semibold uppercase tracking-[0.14em] text-[#090a0d] bg-gradient-to-r from-[#d9b16f] via-[#f3d59a] to-[#d9b16f] hover:brightness-105 disabled:opacity-50 transition-all rounded-sm shadow-[0_4px_20px_rgba(217,177,111,0.3)] cursor-pointer"
              >
                {isSubmitting ? (
                  <span>Processing Commercial Dispatch...</span>
                ) : (
                  <>
                    <span>Submit Export Enquiry</span>
                    <Send className="w-4 h-4 text-[#090a0d]" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </section>
  );
};
