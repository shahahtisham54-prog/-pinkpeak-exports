import React, { useState } from 'react';
import { ArrowRight, Info, CheckCircle2, X } from 'lucide-react';
import { BRAND_CONFIG, ProductItem } from '../config/brand';

interface ProductsSectionProps {
  onSelectProductForQuote: (productName: string) => void;
}

export const ProductsSection: React.FC<ProductsSectionProps> = ({ onSelectProductForQuote }) => {
  const [selectedProductDetails, setSelectedProductDetails] = useState<ProductItem | null>(null);

  return (
    <section id="products" className="py-24 bg-[#090a0d] relative overflow-hidden">
      {/* Subtle ambient mineral glow */}
      <div className="absolute top-1/4 right-0 w-96 h-96 bg-[radial-gradient(circle,rgba(216,154,157,0.08),transparent_70%)] pointer-events-none" />
      <div className="absolute bottom-10 left-0 w-80 h-80 bg-[radial-gradient(circle,rgba(217,177,111,0.06),transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
            <span>OUR PRODUCT RANGE</span>
            <span className="w-5 h-[1px] bg-[#d9b16f]" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury font-normal text-[#f7f3ed] mb-5 tracking-tight">
            Discover the World of Himalayan Pink Salt
          </h2>
          <p className="text-base text-[#bdb7b0] font-light leading-relaxed">
            Explore different forms of Himalayan pink salt for food, retail, wellness, decorative
            products, and wholesale distribution.
          </p>
          <div className="mt-4 text-xs text-[#d89a9d]/90 italic">
            * Product availability, mesh grades, packaging sizes, and commercial order terms are confirmed upon enquiry.
          </div>
        </div>

        {/* 6 Premium Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {BRAND_CONFIG.products.map((product) => (
            <div
              key={product.id}
              className="bg-[#121317] border border-[#d9b16f]/20 hover:border-[#d9b16f]/60 rounded-sm overflow-hidden flex flex-col group transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_12px_36px_rgba(0,0,0,0.6)]"
            >
              {/* Product Photograph with zoom hover */}
              <div className="relative aspect-[4/3] overflow-hidden bg-[#1b1b20]">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-108"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121317] via-[#121317]/20 to-transparent opacity-80" />

                {/* Category label */}
                <div className="absolute top-3 left-3 text-[11px] uppercase tracking-wider text-[#d9b16f] font-medium bg-[#090a0d]/80 backdrop-blur-sm px-2.5 py-1 rounded-sm border border-[#d9b16f]/20">
                  {product.category}
                </div>

                {/* Quick specs trigger button */}
                <button
                  onClick={() => setSelectedProductDetails(product)}
                  className="absolute top-3 right-3 p-1.5 rounded-sm bg-[#090a0d]/70 text-[#bdb7b0] hover:text-[#f3d59a] border border-white/10 hover:border-[#d9b16f]/50 transition-all opacity-0 group-hover:opacity-100"
                  title="View detailed product specifications"
                  aria-label={`View detailed specifications for ${product.name}`}
                >
                  <Info className="w-4 h-4" />
                </button>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-serif-luxury font-semibold text-[#f7f3ed] group-hover:text-[#f3d59a] transition-colors mb-2">
                    {product.name}
                  </h3>
                  <p className="text-xs text-[#d89a9d] font-medium mb-3">
                    {product.tagline}
                  </p>
                  <p className="text-sm text-[#bdb7b0] font-light leading-relaxed mb-6">
                    {product.description}
                  </p>
                </div>

                {/* Action CTA */}
                <div className="pt-4 border-t border-white/5 flex items-center justify-between gap-3">
                  <button
                    onClick={() => onSelectProductForQuote(product.name)}
                    className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#d9b16f] hover:text-[#f3d59a] transition-colors group/btn cursor-pointer"
                  >
                    <span>{product.ctaText}</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover/btn:translate-x-1" />
                  </button>

                  <button
                    onClick={() => setSelectedProductDetails(product)}
                    className="text-[11px] text-[#bdb7b0] hover:text-[#f7f3ed] underline underline-offset-4 decoration-white/20 hover:decoration-[#d9b16f] transition-all cursor-pointer"
                  >
                    Specs
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Product Specification Modal */}
      {selectedProductDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#121317] border border-[#d9b16f]/40 rounded-sm max-w-xl w-full p-6 sm:p-8 relative shadow-2xl max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setSelectedProductDetails(null)}
              className="absolute top-4 right-4 text-[#bdb7b0] hover:text-[#f7f3ed] p-1.5 rounded-sm hover:bg-white/5 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-2 text-xs uppercase tracking-widest text-[#d9b16f]">
              <span>SPECIFICATION SHEET</span>
              <span>·</span>
              <span>{selectedProductDetails.category}</span>
            </div>

            <h3 className="text-2xl font-serif-luxury font-semibold text-[#f7f3ed] mb-2">
              {selectedProductDetails.name}
            </h3>
            <p className="text-sm text-[#bdb7b0] mb-6">
              {selectedProductDetails.description}
            </p>

            <div className="space-y-4 mb-8 text-xs sm:text-sm">
              <div className="p-3 bg-[#1b1b20] rounded border border-white/5">
                <span className="text-[#d9b16f] font-semibold block mb-1">Geological Origin:</span>
                <span className="text-[#f7f3ed]">{selectedProductDetails.detailedSpecs.origin}</span>
              </div>

              {selectedProductDetails.detailedSpecs.grainSize && (
                <div className="p-3 bg-[#1b1b20] rounded border border-white/5">
                  <span className="text-[#d9b16f] font-semibold block mb-1">Granulometry / Mesh Sizes:</span>
                  <span className="text-[#f7f3ed]">{selectedProductDetails.detailedSpecs.grainSize}</span>
                </div>
              )}

              <div className="p-3 bg-[#1b1b20] rounded border border-white/5">
                <span className="text-[#d9b16f] font-semibold block mb-1">Mineral Tones & Color Profile:</span>
                <span className="text-[#f7f3ed]">{selectedProductDetails.detailedSpecs.colorProfile}</span>
              </div>

              <div className="p-3 bg-[#1b1b20] rounded border border-white/5">
                <span className="text-[#d9b16f] font-semibold block mb-1.5">Standard Packaging Formats:</span>
                <ul className="grid grid-cols-1 gap-1">
                  {selectedProductDetails.detailedSpecs.packagingOptions.map((opt, i) => (
                    <li key={i} className="flex items-center gap-2 text-[#bdb7b0]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#d89a9d] shrink-0" />
                      <span>{opt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 bg-[#1b1b20] rounded border border-white/5">
                <span className="text-[#d9b16f] font-semibold block mb-1">Export Packing & Maritime Protection:</span>
                <span className="text-[#bdb7b0]">{selectedProductDetails.detailedSpecs.exportPacking}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <button
                onClick={() => {
                  const prod = selectedProductDetails.name;
                  setSelectedProductDetails(null);
                  onSelectProductForQuote(prod);
                }}
                className="w-full sm:w-auto flex-1 px-6 py-3 bg-gradient-to-r from-[#d9b16f] to-[#f3d59a] text-[#090a0d] font-semibold text-xs uppercase tracking-wider rounded-sm text-center cursor-pointer shadow-md"
              >
                Request Quotation for This Product
              </button>
              <button
                onClick={() => setSelectedProductDetails(null)}
                className="w-full sm:w-auto px-5 py-3 border border-white/20 text-[#bdb7b0] hover:text-[#f7f3ed] text-xs font-semibold uppercase tracking-wider rounded-sm cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
