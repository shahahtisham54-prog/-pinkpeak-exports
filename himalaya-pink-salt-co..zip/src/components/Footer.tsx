import React from 'react';
import { Mail, MapPin, Phone } from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { BRAND_CONFIG } from '../config/brand';

interface FooterProps {
  onSelectProduct: (productName: string) => void;
  onRequestQuote: () => void;
  onNavigate: (href: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectProduct, onRequestQuote, onNavigate }) => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#090a0d] border-t border-[#d9b16f]/20 text-[#bdb7b0] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-14 border-b border-white/5">
          {/* Column 1: Brand & Origin (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <BrandLogo size="md" showSubtitle={true} />
            <p className="text-xs uppercase tracking-widest text-[#d9b16f] font-medium pt-1">
              {BRAND_CONFIG.tagline}
            </p>
            <p className="text-xs sm:text-sm text-[#bdb7b0] font-light leading-relaxed max-w-sm">
              International B2B exporter of authentic Pakistani Himalayan pink salt minerals,
              culinary crystals, decorative luminaires, and bespoke private-label packaging.
            </p>
            <div className="pt-2">
              <span className="text-[11px] text-[#d89a9d] block">
                Geological Extraction: {BRAND_CONFIG.saltMineOrigin}
              </span>
            </div>
          </div>

          {/* Column 2: Products (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="font-serif-luxury text-base font-semibold text-[#f7f3ed] uppercase tracking-wider mb-4 border-b border-[#d9b16f]/20 pb-2 inline-block">
              Products
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              {[
                { name: 'Food-Grade Pink Salt', key: 'Food-Grade Pink Salt' },
                { name: 'Fine & Coarse Salt', key: 'Fine or Coarse Pink Salt' },
                { name: 'Salt Chunks', key: 'Pink Salt Chunks' },
                { name: 'Pink Salt Lamps', key: 'Pink Salt Lamps' },
                { name: 'Private Label Products', key: 'Private Label Products' },
              ].map((item) => (
                <li key={item.key}>
                  <button
                    onClick={() => onSelectProduct(item.key)}
                    className="hover:text-[#f3d59a] transition-colors text-left cursor-pointer"
                  >
                    {item.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Export Enquiries (2 cols) */}
          <div className="lg:col-span-2">
            <h4 className="font-serif-luxury text-base font-semibold text-[#f7f3ed] uppercase tracking-wider mb-4 border-b border-[#d9b16f]/20 pb-2 inline-block">
              Export Enquiries
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate('#wholesale')}
                  className="hover:text-[#f3d59a] transition-colors text-left cursor-pointer"
                >
                  Wholesale Supply
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('#private-label')}
                  className="hover:text-[#f3d59a] transition-colors text-left cursor-pointer"
                >
                  Packaging Options
                </button>
              </li>
              <li>
                <button
                  onClick={onRequestQuote}
                  className="hover:text-[#f3d59a] text-[#d9b16f] font-medium transition-colors text-left cursor-pointer"
                >
                  Request a Quote
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('#contact')}
                  className="hover:text-[#f3d59a] transition-colors text-left cursor-pointer"
                >
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact & Coordinates (3 cols) */}
          <div className="lg:col-span-3">
            <h4 className="font-serif-luxury text-base font-semibold text-[#f7f3ed] uppercase tracking-wider mb-4 border-b border-[#d9b16f]/20 pb-2 inline-block">
              Contact
            </h4>
            <div className="space-y-3 text-xs sm:text-sm">
              <div className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#d9b16f] shrink-0 mt-0.5" />
                <a
                  href={`mailto:${BRAND_CONFIG.contactEmail}`}
                  className="text-[#f7f3ed] hover:text-[#f3d59a] transition-colors break-all"
                >
                  {BRAND_CONFIG.contactEmail}
                </a>
              </div>

              {BRAND_CONFIG.whatsAppNumber && (
                <div className="flex items-start gap-2.5">
                  <Phone className="w-4 h-4 text-[#d9b16f] shrink-0 mt-0.5" />
                  <span className="text-[#f7f3ed]">{BRAND_CONFIG.whatsAppNumber}</span>
                </div>
              )}

              {BRAND_CONFIG.businessAddress?.fullLocation && (
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-[#d9b16f] shrink-0 mt-0.5" />
                  <span className="text-[#bdb7b0] leading-relaxed">
                    {BRAND_CONFIG.businessAddress.fullLocation}
                  </span>
                </div>
              )}

              <div className="pt-2 text-[11px] text-[#bdb7b0]/70">
                Official B2B Trade & Logistics Desk
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Terms */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#bdb7b0]/60">
          <div>
            © {currentYear} {BRAND_CONFIG.legalEntityName || BRAND_CONFIG.name}. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Pakistani Himalayan Pink Salt Export Portal</span>
            <span>·</span>
            <span>Incoterms 2020 Compliant</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
