import React from 'react';
import { Sparkles, Grid3X3, Globe2 } from 'lucide-react';

export const WhyPakistanSalt: React.FC = () => {
  const pillars = [
    {
      icon: Sparkles,
      title: 'Natural Mineral Appearance',
      description:
        'Distinctive crystal shapes and naturally occurring color variations ranging from light blush to deep rose amber.',
    },
    {
      icon: Grid3X3,
      title: 'Multiple Product Formats',
      description:
        'Different grades, crystal sizes, and product forms can be explored for suitable culinary, wellness, and decorative markets.',
    },
    {
      icon: Globe2,
      title: 'International Business Focus',
      description:
        'Product specifications, export documentation, and commercial requirements discussed transparently with wholesale buyers worldwide.',
    },
  ];

  return (
    <section id="about-salt" className="py-24 bg-[#121317] relative border-t border-b border-[#d9b16f]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Authentic Photography of Salt Rocks */}
          <div className="lg:col-span-5 order-2 lg:order-1">
            <div className="relative rounded-sm overflow-hidden border border-[#d9b16f]/30 p-2 bg-[#1b1b20]">
              <div className="relative aspect-[4/3] rounded-sm overflow-hidden">
                <img
                  src="/src/assets/images/natural_salt_chunks_1792434904307.jpg"
                  alt="Raw natural Himalayan pink salt crystal rocks showing authentic geological striations from Pakistan"
                  className="w-full h-full object-cover object-center"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#090a0d] via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="text-[11px] uppercase tracking-wider text-[#d9b16f] font-semibold">
                    GEOLOGICAL HERITAGE
                  </div>
                  <div className="text-xs text-[#bdb7b0]">
                    Sub-Himalayan Salt Range formation, Punjab, Pakistan
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Overview */}
          <div className="lg:col-span-7 order-1 lg:order-2">
            <div className="inline-flex items-center gap-2 mb-3 text-xs uppercase tracking-[0.25em] text-[#d9b16f] font-semibold">
              <span className="w-5 h-[1px] bg-[#d9b16f]" />
              <span>ORIGIN & AUTHENTICITY</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif-luxury text-[#f7f3ed] mb-6 tracking-tight leading-[1.15]">
              A Distinctive Mineral. <br />
              <span className="italic text-[#f3d59a]">A Recognizable Origin.</span>
            </h2>

            <p className="text-base sm:text-lg text-[#bdb7b0] font-light leading-relaxed mb-8">
              Pakistan is known for its Himalayan pink salt deposits. The salt's natural variation in
              pink, blush, peach, and off-white tones gives it a distinctive appearance across different
              product forms.
            </p>

            {/* 3 Pillars */}
            <div className="space-y-6">
              {pillars.map((pillar, idx) => {
                const Icon = pillar.icon;
                return (
                  <div key={idx} className="flex items-start gap-4 group">
                    <div className="w-10 h-10 rounded-sm bg-[#1b1b20] border border-[#d9b16f]/30 flex items-center justify-center text-[#d9b16f] shrink-0 mt-1 group-hover:border-[#d9b16f] group-hover:text-[#f3d59a] transition-colors">
                      <Icon className="w-5 h-5 stroke-[1.5]" />
                    </div>
                    <div>
                      <h3 className="font-serif-luxury text-lg font-semibold text-[#f7f3ed] group-hover:text-[#f3d59a] transition-colors mb-1">
                        {pillar.title}
                      </h3>
                      <p className="text-sm text-[#bdb7b0] font-light leading-relaxed">
                        {pillar.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
