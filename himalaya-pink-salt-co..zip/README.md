# HIMALAYA PINK SALT CO. — Export Web Portal

A premium, luxury-styled international export web platform for Pakistani Himalayan Pink Salt. Designed specifically for B2B international trade, wholesale importers, bulk distributors, private-label brands, and supermarket buyers.

## Brand Identity & Colors

- **Working Brand**: HIMALAYA PINK SALT CO.
- **Tagline**: From Pakistan's Salt Mountains to the World.
- **Header Subtitle**: PAKISTAN · GLOBAL EXPORTS
- **Palette**:
  - Primary Background: `#090A0D`
  - Secondary Background: `#121317`
  - Card Background: `#1B1B20`
  - Champagne Gold: `#D9B16F`
  - Warm Gold Highlight: `#F3D59A`
  - Himalayan Salt Pink: `#D89A9D`
  - Crystal Blush: `#F0D2D0`
  - Primary Text: `#F7F3ED`
  - Secondary Text: `#BDB7B0`

---

## 🛠️ Central Configuration (`src/config/brand.ts`)

All brand information, product specifications, email destinations, and WhatsApp numbers are configured in a single file:
`src/config/brand.ts`

To customize the website for your business:
1. Open `src/config/brand.ts`.
2. Update:
   - `name`: Your company name.
   - `contactEmail`: Your official corporate email where export inquiries should go.
   - `whatsAppNumber`: Your verified international phone number (e.g. `"923001234567"`). *Note: If left empty, the floating WhatsApp button remains hidden.*
   - `businessAddress`: Your physical export coordination office / warehouse hub.
   - `products`: Product catalog, packaging types, and mesh grades.

---

## 🚀 Local Development

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Run local development server**:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) (or the port specified by Vite) to view the site.

3. **Build for production**:
   ```bash
   npm run build
   ```
   This generates a static production build in the `dist/` directory.

---

## 🌐 Hostinger Deployment Guide

This project is built as a pure, lightning-fast static single-page application (SPA). It runs on any standard Hostinger Shared, Cloud, or VPS hosting package without needing a permanent Node.js server.

### Step-by-Step Hostinger Upload:

1. **Build the production bundle locally**:
   ```bash
   npm run build
   ```
   This creates the `dist/` folder containing `index.html`, assets, images, `favicon.svg`, `robots.txt`, and `sitemap.xml`.

2. **Log into Hostinger hPanel**:
   - Go to your Hostinger dashboard and select **Websites** -> your domain.
   - Navigate to **Files** -> **File Manager** (or connect via FTP / FileZilla).

3. **Navigate to `public_html`**:
   - Open the `public_html/` root folder (or your subdomain folder).

4. **Upload files**:
   - Upload all files and folders directly inside `dist/` into `public_html/`.
   - Your `public_html/` should contain:
     - `index.html`
     - `favicon.svg`
     - `robots.txt`
     - `sitemap.xml`
     - `assets/`

5. **SPA Routing on Hostinger (Apache .htaccess)**:
   Ensure clean client-side routing by creating or updating `.htaccess` inside `public_html/` with:
   ```apache
   <IfModule mod_rewrite.c>
     RewriteEngine On
     RewriteBase /
     RewriteRule ^index\.html$ - [L]
     RewriteCond %{REQUEST_FILENAME} !-f
     RewriteCond %{REQUEST_FILENAME} !-d
     RewriteRule . /index.html [L]
   </IfModule>
   ```

---

## 📬 Contact & Export Inquiry Form Backend

The inquiry form works out of the box with zero setup using an honest `mailto:` fallback:
- When submitted without a custom API backend, it formats the complete B2B requirements into an email draft pre-addressed to your configured email in `brand.ts`.

### Optional: Connecting a Custom Endpoint
If you wish to receive inquiries directly via webhook, Formspree, Zapier, or a custom API:
1. In your `.env` or Hostinger environment configuration, set:
   ```env
   VITE_CONTACT_FORM_ENDPOINT="https://formspree.io/f/your_form_id"
   ```
2. Re-run `npm run build`. The form will automatically POST JSON data directly to your endpoint with fallback protection.
